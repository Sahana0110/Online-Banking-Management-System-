﻿namespace bank
{
    partial class BankMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.label8 = new System.Windows.Forms.Label();
            this.guna2CustomGradientPanel1 = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.panelUSER = new Guna.UI2.WinForms.Guna2Panel();
            this.guna2Button8 = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.MainPanel = new Guna.UI2.WinForms.Guna2CustomGradientPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.guna2Button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnUsers = new Guna.UI2.WinForms.Guna2Button();
            this.btnAtm = new Guna.UI2.WinForms.Guna2Button();
            this.btnLogout = new Guna.UI2.WinForms.Guna2Button();
            this.btnoperation = new Guna.UI2.WinForms.Guna2Button();
            this.btnClients = new Guna.UI2.WinForms.Guna2Button();
            this.btnTransactions = new Guna.UI2.WinForms.Guna2Button();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.guna2CustomGradientPanel1.SuspendLayout();
            this.panelUSER.SuspendLayout();
            this.guna2GradientPanel1.SuspendLayout();
            this.MainPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.BorderRadius = 40;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label8.Font = new System.Drawing.Font("Lucida Calligraphy", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label8.Location = new System.Drawing.Point(-3, 83);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 39);
            this.label8.TabIndex = 8;
            this.label8.Text = "Islamic Bank";
            // 
            // guna2CustomGradientPanel1
            // 
            this.guna2CustomGradientPanel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.guna2CustomGradientPanel1.BorderRadius = 30;
            this.guna2CustomGradientPanel1.Controls.Add(this.panelUSER);
            this.guna2CustomGradientPanel1.Controls.Add(this.guna2GradientPanel1);
            this.guna2CustomGradientPanel1.Controls.Add(this.MainPanel);
            this.guna2CustomGradientPanel1.FillColor = System.Drawing.SystemColors.HotTrack;
            this.guna2CustomGradientPanel1.FillColor2 = System.Drawing.SystemColors.HotTrack;
            this.guna2CustomGradientPanel1.FillColor3 = System.Drawing.SystemColors.HotTrack;
            this.guna2CustomGradientPanel1.FillColor4 = System.Drawing.SystemColors.HotTrack;
            this.guna2CustomGradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.guna2CustomGradientPanel1.Name = "guna2CustomGradientPanel1";
            this.guna2CustomGradientPanel1.Size = new System.Drawing.Size(1056, 596);
            this.guna2CustomGradientPanel1.TabIndex = 9;
            this.guna2CustomGradientPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2CustomGradientPanel1_Paint);
            // 
            // panelUSER
            // 
            this.panelUSER.BackColor = System.Drawing.SystemColors.HotTrack;
            this.panelUSER.Controls.Add(this.guna2Button8);
            this.panelUSER.Controls.Add(this.label2);
            this.panelUSER.Controls.Add(this.lbluser);
            this.panelUSER.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelUSER.Location = new System.Drawing.Point(199, 0);
            this.panelUSER.Name = "panelUSER";
            this.panelUSER.Size = new System.Drawing.Size(857, 69);
            this.panelUSER.TabIndex = 19;
            this.panelUSER.Paint += new System.Windows.Forms.PaintEventHandler(this.guna2Panel1_Paint_1);
            // 
            // guna2Button8
            // 
            this.guna2Button8.BackColor = System.Drawing.Color.SteelBlue;
            this.guna2Button8.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.guna2Button8.BorderRadius = 5;
            this.guna2Button8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button8.FillColor = System.Drawing.SystemColors.HotTrack;
            this.guna2Button8.Font = new System.Drawing.Font("Sitka Small", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2Button8.ForeColor = System.Drawing.Color.White;
            this.guna2Button8.Location = new System.Drawing.Point(798, 0);
            this.guna2Button8.Name = "guna2Button8";
            this.guna2Button8.Size = new System.Drawing.Size(43, 41);
            this.guna2Button8.TabIndex = 18;
            this.guna2Button8.Text = "x";
            this.guna2Button8.Click += new System.EventHandler(this.guna2Button8_Click);
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.HotTrack;
            this.label2.Font = new System.Drawing.Font("Lucida Handwriting", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.label2.Location = new System.Drawing.Point(6, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(246, 38);
            this.label2.TabIndex = 17;
            this.label2.Text = "Welcome Back";
            // 
            // lbluser
            // 
            this.lbluser.BackColor = System.Drawing.SystemColors.HotTrack;
            this.lbluser.Font = new System.Drawing.Font("Lucida Handwriting", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluser.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbluser.Location = new System.Drawing.Point(21, 3);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(264, 28);
            this.lbluser.TabIndex = 16;
            this.lbluser.Click += new System.EventHandler(this.lbluser_Click);
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.guna2GradientPanel1.Controls.Add(this.pictureBox1);
            this.guna2GradientPanel1.Controls.Add(this.guna2Button1);
            this.guna2GradientPanel1.Controls.Add(this.btnUsers);
            this.guna2GradientPanel1.Controls.Add(this.btnAtm);
            this.guna2GradientPanel1.Controls.Add(this.btnLogout);
            this.guna2GradientPanel1.Controls.Add(this.btnoperation);
            this.guna2GradientPanel1.Controls.Add(this.btnClients);
            this.guna2GradientPanel1.Controls.Add(this.label8);
            this.guna2GradientPanel1.Controls.Add(this.btnTransactions);
            this.guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(199, 596);
            this.guna2GradientPanel1.TabIndex = 1;
            // 
            // MainPanel
            // 
            this.MainPanel.BackColor = System.Drawing.SystemColors.HotTrack;
            this.MainPanel.BorderRadius = 50;
            this.MainPanel.Controls.Add(this.label1);
            this.MainPanel.Controls.Add(this.pictureBox9);
            this.MainPanel.Controls.Add(this.pictureBox4);
            this.MainPanel.Location = new System.Drawing.Point(199, 59);
            this.MainPanel.Name = "MainPanel";
            this.MainPanel.Size = new System.Drawing.Size(841, 514);
            this.MainPanel.TabIndex = 18;
            this.MainPanel.Paint += new System.Windows.Forms.PaintEventHandler(this.MainPanel_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(291, 24);
            this.label1.TabIndex = 8;
            this.label1.Text = "Islamic Bank :  save your money";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::bank.Properties.Resources.How_to_Draw_a_Bank1;
            this.pictureBox1.Location = new System.Drawing.Point(36, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(113, 77);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // guna2Button1
            // 
            this.guna2Button1.Animated = true;
            this.guna2Button1.AutoRoundedCorners = true;
            this.guna2Button1.BackColor = System.Drawing.SystemColors.HotTrack;
            this.guna2Button1.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.guna2Button1.BorderRadius = 24;
            this.guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2Button1.FillColor = System.Drawing.SystemColors.HotTrack;
            this.guna2Button1.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.guna2Button1.ForeColor = System.Drawing.SystemColors.Window;
            this.guna2Button1.Image = global::bank.Properties.Resources.icons8_dashboard_64;
            this.guna2Button1.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.guna2Button1.ImageSize = new System.Drawing.Size(40, 40);
            this.guna2Button1.Location = new System.Drawing.Point(0, 135);
            this.guna2Button1.Name = "guna2Button1";
            this.guna2Button1.Size = new System.Drawing.Size(201, 51);
            this.guna2Button1.TabIndex = 11;
            this.guna2Button1.Text = "Dashboard";
            this.guna2Button1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.guna2Button1_MouseClick);
            // 
            // btnUsers
            // 
            this.btnUsers.Animated = true;
            this.btnUsers.AutoRoundedCorners = true;
            this.btnUsers.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnUsers.BorderColor = System.Drawing.SystemColors.HotTrack;
            this.btnUsers.BorderRadius = 22;
            this.btnUsers.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnUsers.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnUsers.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnUsers.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnUsers.FillColor = System.Drawing.SystemColors.HotTrack;
            this.btnUsers.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnUsers.ForeColor = System.Drawing.SystemColors.Window;
            this.btnUsers.Image = global::bank.Properties.Resources.icons8_admin_settings_male_64;
            this.btnUsers.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnUsers.ImageSize = new System.Drawing.Size(40, 40);
            this.btnUsers.Location = new System.Drawing.Point(-4, 272);
            this.btnUsers.Name = "btnUsers";
            this.btnUsers.Size = new System.Drawing.Size(203, 47);
            this.btnUsers.TabIndex = 11;
            this.btnUsers.Text = "Users";
            this.btnUsers.Click += new System.EventHandler(this.guna2Button3_Click);
            this.btnUsers.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnUsers_MouseClick);
            // 
            // btnAtm
            // 
            this.btnAtm.Animated = true;
            this.btnAtm.AutoRoundedCorners = true;
            this.btnAtm.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnAtm.BorderRadius = 16;
            this.btnAtm.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnAtm.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnAtm.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnAtm.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnAtm.FillColor = System.Drawing.SystemColors.HotTrack;
            this.btnAtm.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnAtm.ForeColor = System.Drawing.SystemColors.Window;
            this.btnAtm.Image = global::bank.Properties.Resources.download__2_;
            this.btnAtm.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnAtm.ImageSize = new System.Drawing.Size(40, 40);
            this.btnAtm.Location = new System.Drawing.Point(0, 464);
            this.btnAtm.Name = "btnAtm";
            this.btnAtm.Size = new System.Drawing.Size(199, 35);
            this.btnAtm.TabIndex = 14;
            this.btnAtm.Text = "ATM";
            this.btnAtm.Click += new System.EventHandler(this.guna2Button4_Click);
            this.btnAtm.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnAtm_MouseClick);
            // 
            // btnLogout
            // 
            this.btnLogout.Animated = true;
            this.btnLogout.AutoRoundedCorners = true;
            this.btnLogout.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnLogout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btnLogout.BorderRadius = 18;
            this.btnLogout.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnLogout.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnLogout.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnLogout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnLogout.FillColor = System.Drawing.SystemColors.HotTrack;
            this.btnLogout.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnLogout.ForeColor = System.Drawing.SystemColors.Window;
            this.btnLogout.Image = global::bank.Properties.Resources._7124045_logout_icon1;
            this.btnLogout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnLogout.ImageSize = new System.Drawing.Size(40, 40);
            this.btnLogout.Location = new System.Drawing.Point(-4, 534);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(203, 39);
            this.btnLogout.TabIndex = 15;
            this.btnLogout.Text = "Log out";
            this.btnLogout.Click += new System.EventHandler(this.guna2Button7_Click);
            // 
            // btnoperation
            // 
            this.btnoperation.Animated = true;
            this.btnoperation.AutoRoundedCorners = true;
            this.btnoperation.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnoperation.BorderRadius = 23;
            this.btnoperation.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnoperation.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnoperation.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnoperation.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnoperation.FillColor = System.Drawing.SystemColors.HotTrack;
            this.btnoperation.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnoperation.ForeColor = System.Drawing.SystemColors.Window;
            this.btnoperation.Image = global::bank.Properties.Resources.icons8_cash_in_hand_16;
            this.btnoperation.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnoperation.ImageSize = new System.Drawing.Size(40, 40);
            this.btnoperation.Location = new System.Drawing.Point(0, 395);
            this.btnoperation.Name = "btnoperation";
            this.btnoperation.Size = new System.Drawing.Size(201, 48);
            this.btnoperation.TabIndex = 13;
            this.btnoperation.Text = "Operations";
            this.btnoperation.Click += new System.EventHandler(this.guna2Button5_Click);
            this.btnoperation.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnoperation_MouseClick);
            // 
            // btnClients
            // 
            this.btnClients.Animated = true;
            this.btnClients.AutoRoundedCorners = true;
            this.btnClients.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnClients.BorderRadius = 23;
            this.btnClients.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnClients.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnClients.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnClients.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnClients.FillColor = System.Drawing.SystemColors.HotTrack;
            this.btnClients.Font = new System.Drawing.Font("Times New Roman", 15.75F);
            this.btnClients.ForeColor = System.Drawing.SystemColors.Window;
            this.btnClients.Image = global::bank.Properties.Resources.icons8_admin_1001;
            this.btnClients.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnClients.ImageSize = new System.Drawing.Size(45, 45);
            this.btnClients.Location = new System.Drawing.Point(3, 206);
            this.btnClients.Name = "btnClients";
            this.btnClients.Size = new System.Drawing.Size(196, 48);
            this.btnClients.TabIndex = 10;
            this.btnClients.Text = "Clients";
            this.btnClients.Click += new System.EventHandler(this.guna2Button1_Click);
            this.btnClients.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnClients_MouseClick);
            // 
            // btnTransactions
            // 
            this.btnTransactions.Animated = true;
            this.btnTransactions.AutoRoundedCorners = true;
            this.btnTransactions.BackColor = System.Drawing.SystemColors.HotTrack;
            this.btnTransactions.BorderRadius = 26;
            this.btnTransactions.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnTransactions.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnTransactions.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnTransactions.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnTransactions.FillColor = System.Drawing.SystemColors.HotTrack;
            this.btnTransactions.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTransactions.ForeColor = System.Drawing.SystemColors.Window;
            this.btnTransactions.Image = global::bank.Properties.Resources.icons8_sync_settings_48;
            this.btnTransactions.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.btnTransactions.ImageSize = new System.Drawing.Size(40, 40);
            this.btnTransactions.Location = new System.Drawing.Point(3, 334);
            this.btnTransactions.Name = "btnTransactions";
            this.btnTransactions.Size = new System.Drawing.Size(198, 55);
            this.btnTransactions.TabIndex = 12;
            this.btnTransactions.Text = "Transactions";
            this.btnTransactions.Click += new System.EventHandler(this.guna2Button6_Click);
            this.btnTransactions.MouseClick += new System.Windows.Forms.MouseEventHandler(this.btnTransactions_MouseClick);
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.White;
            this.pictureBox9.Image = global::bank.Properties.Resources.Online_Banking;
            this.pictureBox9.Location = new System.Drawing.Point(419, 36);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(402, 425);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 0;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::bank.Properties.Resources.download;
            this.pictureBox4.Location = new System.Drawing.Point(326, -95);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(77, 75);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // BankMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1052, 596);
            this.Controls.Add(this.guna2CustomGradientPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "BankMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "BankMain";
            this.Load += new System.EventHandler(this.BankMain_Load);
            this.guna2CustomGradientPanel1.ResumeLayout(false);
            this.panelUSER.ResumeLayout(false);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.MainPanel.ResumeLayout(false);
            this.MainPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel guna2CustomGradientPanel1;
        private Guna.UI2.WinForms.Guna2Button btnUsers;
        private Guna.UI2.WinForms.Guna2Button btnAtm;
        private Guna.UI2.WinForms.Guna2Button btnClients;
        private Guna.UI2.WinForms.Guna2Button btnoperation;
        private Guna.UI2.WinForms.Guna2Button btnLogout;
        private Guna.UI2.WinForms.Guna2Button btnTransactions;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Label label2;
        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2Panel panelUSER;
        private Guna.UI2.WinForms.Guna2Button guna2Button8;
        private Guna.UI2.WinForms.Guna2Button guna2Button1;
        private Guna.UI2.WinForms.Guna2CustomGradientPanel MainPanel;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}